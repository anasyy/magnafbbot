<?php

return [
    'verify_token' => 'Token123Test',
    'token' => 'EAABgZCEcIOZCkBAMxZAMNrOWDZB1Bz2rBc9dtKIZCo9nZBqA9I0lZCasEqaXNICj2IquCqrdp8Ld3H5p1WQHD3wBszc2p5zBjWLcw1FgMxpQHEzz7KKDwePClrb2AhQtBgC1w0FnuwMZCsZCttdXO4hPm2rBwOhuZBl6qMgLR19DfHN7ZCZAlpZBkaYZCX'
];